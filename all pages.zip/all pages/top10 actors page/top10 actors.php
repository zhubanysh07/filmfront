<?php
try {
    // Create a new PDO instance
    $db = new PDO("mysql:host=localhost;dbname=for site", "root", "");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Initialize the $info array
    $info = [];
    // Execute the query
    $query = $db->query("SELECT * FROM actors");
    // Check if the query was successful
    if ($query) {
    // Fetch all results as an associative array
        $info = $query->fetchAll(PDO::FETCH_ASSOC);
    } else {
    // Print error information if query failed
        print_r($db->errorInfo());
    }
} catch (PDOException $e) {
    // Catch any PDO exceptions and print the error message
    echo "Error: " . $e->getMessage();
}
// Ensure $info is an array to avoid warnings
if (!is_array($info)) {
    $info = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Top 10 actors</title>
    <link rel="stylesheet" href="top10 actors.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <a href="http://127.0.0.1:5502/main.html"><img src="logo.png" alt="FilmFront" height="120" width="160"></a>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="Search...">
                <i class="fas fa-search"></i>
            </div>
            <div class="menu-icon">
                <input type="checkbox" id="menu-toggle">
                <label for="menu-toggle">&#9776;</label>
                <div class="menu-dropdown">
                    <ul>
                        <li><a href="http://localhost/Top-10%20films/Top-10%20films/top10films.php">Top-10 films</a></li>
                        <li><a href="http://localhost/top10%20actors%20page/top10%20actors.php">Top-10 actors</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>
    <main>
        <div class="top10"><img src="Vector.png" alt="#"><p>Top 10 Actors</p></div>
        <?php foreach($info as $data): ?>
            <div class="cillian">
                <div class="back-img"><img src="<?= htmlspecialchars($data['back_img']) ?>" height="850px" alt="#"></div>
                <div class="main-img"><img src="<?= htmlspecialchars($data['image']) ?>" alt="<?= htmlspecialchars($data['full_name']) ?>" width="250px" height="360px"></div>
                <h2><?= htmlspecialchars($data['full_name']) ?></h2>
                <div class="age"><p>Age: <?= htmlspecialchars($data['age']) ?></p></div>
                <div class="films"><p>Films:</p> <h4><?= htmlspecialchars($data['films']) ?></h4></div>
            </div>
            <div class="cillian-films">
                <div class="film_name1"><a href="#"><img src="<?= htmlspecialchars($data['film1']) ?>" alt="#"></a>
                    <p><?= htmlspecialchars($data['film_name1']) ?></p>
                </div>
                <div class="film_name2"><a href="#"><img src="<?= htmlspecialchars($data['film2']) ?>" alt="#"></a>
                    <p><?= htmlspecialchars($data['film_name2']) ?></p>
                </div>
                <div class="film_name3"><a href="#"><img src="<?= htmlspecialchars($data['film3']) ?>" alt="#"></a>
                    <p><?= htmlspecialchars($data['film_name3']) ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    </main>
    <div class="all_footer">
        <footer>
            <div class="sitename1"><p>FILM</p></div>
            <div class="footer_section">
                <div class="copyright"><p>© 2003 — 2024, FilmFront</p></div>
                <div class="inside">
                    <p>
                        <a href="#">Job_openings</a>       
                        <a href="#">Advertisement</a>          
                        <a href="#">Agreement</a>          
                        <a href="#">Rules_of_recommendations</a>          
                        <a href="#">Reference</a>          
                        <a href="#">The_blog</a>          
                        <a href="#">Offers</a> 
                        <a href="#">All_movies</a>          
                        <a href="#">All_series</a>          
                        <a href="#">All_cartoons</a>          
                        <a href="#">Broadcasts_and_shows</a>          
                        <a href="#">Movie_Recommendation</a>
                        <a href="#">Promotions_and_subscriptions</a>          
                        <a href="#">Support_Service</a>
                    </p>
                    <div class="icons">
                        <a href="https://www.instagram.com/kinopoisk/"><img src="instagram.png" alt="Instagram"></a>
                        <a href="https://web.telegram.org/k/#@kinopoisk"><img src="telegram.png" alt="Telegram"></a>
                        <a href="https://x.com/kinopoiskru"><img src="twitter.png" alt="Twitter"></a>
                    </div>
                </div>
                <div class="copyright"><p>© 2003 — 2024, FilmFront</p></div>
            </div>
            <div class="sitename2"><p>FRONT</p></div>
        </footer> 
    </div>
</body>
</html>