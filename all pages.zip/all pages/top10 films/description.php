<?php
try {
    $db = new PDO("mysql:host=localhost;dbname=for_site", "root", "");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $film_name = isset($_GET['film_name']) ? $_GET['film_name'] : '';
    $film_info = [];

    if ($film_name) {
        $stmt = $db->prepare("SELECT film_name, rating, image, description, directors, writers, date_of_pub, country, genre, duration FROM top10_films WHERE film_name = :film_name");
        $stmt->bindParam(':film_name', $film_name);
        $stmt->execute();
        $film_info = $stmt->fetch(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Description</title>
    <link rel="stylesheet" href="description.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <a href="http://127.0.0.1:5502/main.html"><img src="logo.png" alt="FilmFront" height="120" width="160"></a>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="Search...">
                <i class="fas fa-search"></i>
            </div>
            <div class="menu-icon">
                <input type="checkbox" id="menu-toggle">
                <label for="menu-toggle">&#9776;</label>
                <div class="menu-dropdown">
                    <ul>
                        <li><a href="http://localhost/Top-10%20films/Top-10%20films/top10films.php">Top-10 films</a></li>
                        <li><a href="http://localhost/top10%20actors%20page/top10%20actors.php">Top-10 actors</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>
    <main>
        <?php if ($film_info): ?>
            <div class="description">
                <div class="background">
                    <img src="<?= htmlspecialchars($film_info['image']) ?>" alt="#">
                </div>
                <div class="main-photo">
                    <img src="<?= htmlspecialchars($film_info['image']) ?>" alt="<?= htmlspecialchars($film_info['film_name']) ?>" width="300px">
                </div>
                <div class="full">
                    <div class="name-rate">
                        <p id="p1"><?= htmlspecialchars($film_info['film_name']) ?>&emsp;&emsp;&emsp;</p>
                        <p id="p2"><?= htmlspecialchars($film_info['rating']) ?></p>
                    </div>
                    <div class="about_film">
                        <p><?= htmlspecialchars($film_info['description']) ?></p>
                    </div>
                    <div class="about">
                        <h2>About film</h2>
                    </div>
                    <div class="intro">
                        <div class="desc">
                            <p>Directors:</p>
                            <p>Writers:</p>
                            <p>Date of publication:</p>
                            <p>Country:</p>
                            <p>Genre:</p>
                            <p>Duration:</p>
                        </div>
                        <div class="text">
                            <p><?= htmlspecialchars($film_info['directors']) ?></p>
                            <p><?= htmlspecialchars($film_info['writers']) ?></p>
                            <p><?= htmlspecialchars($film_info['date_of_pub']) ?></p> 
                            <p><?= htmlspecialchars($film_info['country']) ?></p>
                            <p><?= htmlspecialchars($film_info['genre']) ?></p>
                            <p><?= htmlspecialchars($film_info['duration']) ?></p>
                        </div>
                    </div>   
                </div>
            </div>
        <?php else: ?>
            <p>No film information found.</p>
        <?php endif; ?>
    </main>
    <div class="all_footer">
        <footer>
            <div class="sitename1"><p>FILM</p></div>
            <div class="footer_section">
                <div class="copyright"><p>© 2003 — 2024, FilmFront</p></div>
                <div class="inside">
                    <p><a href="#">Job_openings</a>       <a href="#">Advertisement</a>          <a href="#">Agreement</a>          <a href="#">Rules_of_recommendations</a>          <a href="#">Reference</a>          <a href="#">The_blog</a>          <a href="#">Offers</a> 
                        <a href="#">All_movies</a>          <a href="#">All_series</a>          <a href="#">All_cartoons</a>          <a href="#">Broadcasts_and_shows</a>          <a href="#">Movie_Recommendation</a>
                        <a href="#">Promotions_and_subscriptions</a>          <a href="#">Support_Service</a></p>
                    <div class="icons">
                        <a href="https://www.instagram.com/kinopoisk/"><img src="instagram.png" alt="Instagram"></a>
                        <a href="https://web.telegram.org/k/#@kinopoisk" class=""><img src="telegram.png" alt="Telegram"></a>
                        <a href="https://x.com/kinopoiskru" class=""><img src="twitter.png" alt="Twitter"></a>
                    </div>
                </div>
                <div class="copyright"><p>© 2003 — 2024, FilmFront</p></div>
            </div>
            <div class="sitename2"><p>FRONT</p></div>
        </footer> 
    </div>
</body>
</html>
