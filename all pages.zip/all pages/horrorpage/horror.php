<?php
try {
    $db = new PDO("mysql:host=localhost;dbname=for site", "root", "");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $info = [];
    
    $query = $db->query("SELECT film_name, rating, image ,YEAR(date_of_pub) as year, genre FROM films WHERE genre LIKE '%Horror%'");

    if ($query) {
        $info = $query->fetchAll(PDO::FETCH_ASSOC);
    } else {
        print_r($db->errorInfo());
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

if (!is_array($info)) {
    $info = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Horror</title>
    <link rel="stylesheet" href="horror.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<header>
        <div class="container">
            <div class="logo">
                <a href="http://127.0.0.1:5502/main.html"><img src="logo.png" alt="FilmFront" height="120" width="160"></a>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="Search...">
                <i class="fas fa-search"></i>
            </div>
            <div class="menu-icon">
                <input type="checkbox" id="menu-toggle">
                <label for="menu-toggle">&#9776;</label>
                <div class="menu-dropdown">
                    <ul>
                        <li><a href="http://localhost/Top-10%20films/Top-10%20films/top10films.php">Top-10 films</a></li>
                        <li><a href="http://localhost/top10%20actors%20page/top10%20actors.php">Top-10 actors</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>
    <main>
        <div class="top10f"><p>Horror</p></div>
        <i class="fas fa-arrow-left arrow-back-icon"></i>
        <div class="photos-p">
        <?php foreach ($info as $data): ?> 
    <div class="photo1">
        <a href="description.php?film_name=<?= urlencode($data['film_name']) ?>">
            <img src="<?= htmlspecialchars($data['image']) ?>" alt="photo1" class="photo-item">
        </a>
        <div class="film-name"><p><?= htmlspecialchars($data['film_name']) ?></p></div>
        <div class="rating"><i class="fas fa-star photo-icon"></i><span class="rating-number1"><?= htmlspecialchars($data['rating']) ?></span></div>
        <div class="film-genre"><?= htmlspecialchars($data['genre']) ?></div>
        <a href="http://localhost/description%20page/description.php?film_name=<?= urlencode($data['film_name']) ?>"><button class="btn">Watch</button></a>
    </div>
        <?php endforeach; ?>
        </div>
        <div class="all_footer"> 
        <footer> 
        <div class="sitename1"><p>FILM</p></div> 
            <div class="footer_section"> 
                <div class="copyright"><p>© 2003 — 2024, FilmFront</p></div> 
                <div class="inside"> 
                    <p><a href="#">Job_openings</a>       <a href="#">Advertisement</a>          <a href="#">Agreement</a>          <a href="#">Rules_of_recommendations</a>          <a href="#">Reference</a>          <a href="#">The_blog</a>          <a href="#">Offers</a>  
                        <a href="#">All_movies</a>          <a href="#">All_series</a>          <a href="#">All_cartoons</a>          <a href="#">Broadcasts_and_shows</a>          <a href="#">Movie_Recommendation</a> 
                        <a href="#">Promotions_and_subscriptions</a>          <a href="#">Support_Service</a></p> 
                    <div class="icons"> 
                        <a href="https://www.instagram.com/kinopoisk/"><img src="instagram.png" alt="Instagram" height="25px" width="25px"></a> 
                        <a href="https://web.telegram.org/k/#@kinopoisk" class=""><img src="telegram.png" alt="Telegram" height="25px" width="25px"></a> 
                        <a href="https://x.com/kinopoiskru" class=""><img src="twitter.png" alt="Twitter" height="25px" width="25px"></a> 
                    </div> 
                </div> 
                 
                <div class="copyright"><p>© 2003 — 2024, FilmFront</p></div> 
            </div> 
             
            <div class="sitename2"><p>FRONT</p></div> 
             
        </footer>  
        </div>
    </main>
</body>
</html>